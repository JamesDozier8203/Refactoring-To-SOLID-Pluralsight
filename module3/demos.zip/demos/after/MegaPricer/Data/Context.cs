﻿namespace MegaPricer.Data;

public static class Context
{
  public static Dictionary<string, Dictionary<string, object>> Session = new();
}
