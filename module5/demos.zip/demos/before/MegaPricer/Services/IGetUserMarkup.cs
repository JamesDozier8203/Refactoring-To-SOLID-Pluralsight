﻿namespace MegaPricer.Services;

public interface IGetUserMarkup
{
  decimal GetUserMarkup(string userName);
}
