﻿namespace MegaPricer.Interfaces;

public interface IGetUserMarkup
{
  decimal GetUserMarkup(string userName);
}
