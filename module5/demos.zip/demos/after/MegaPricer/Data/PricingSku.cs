﻿namespace MegaPricer.Data;

public class PricingSku
{
  public int PricingSkuId { get; set; }
  public string SKU { get; set; }
  public float WholesalePrice { get; set; }
}
